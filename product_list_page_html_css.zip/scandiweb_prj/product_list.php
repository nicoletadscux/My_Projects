<html> 
<head> </head> 
<body> 

<?php

class Product {

    public $sku;
    public $name;
    public $price;

    public function __construct($sku, $name, $price){

        $this->sku = $sku;
        $this->name = $name;
        $this->price = $price;
    }

    public function getName($name){
        return $this->name
    }

    public function setName($name){
        if(is_string($name) && strlen($name) > 1){
            $this->name = $name;
            echo("The name has been updated to $name.")
        } else {
            echo("Not a valid name!");
        }
    }
}

class DVD_Product extends Product {


}

    $productOne = new Product("AWZ78B2H", "TV stand", 72);
    $productTwo = new Product("BGZ890YHN", "Fridge", 100);
    $productThree = new Product("TRBVNKVH", "Coffee Table", 45);

    echo("These are the product listed: \n");
    echo($productOne);
    echo("\n");
    echo("$productTwo");

?>
</body> 
</html>




